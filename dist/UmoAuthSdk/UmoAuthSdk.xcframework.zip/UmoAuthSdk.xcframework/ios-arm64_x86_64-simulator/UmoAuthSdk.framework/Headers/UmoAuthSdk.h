/*
 * COPYRIGHT - CUBIC TRANSPORTATION SYSTEMS, INC ("CUBIC"). ALL RIGHTS RESERVED.
 *
 * Information Contained Herein is Proprietary and Confidential.
 * The document is the property of "CUBIC" and may not be disclosed
 * distributed, or reproduced  without the express written permission of
 * "CUBIC".
 */

#import <Foundation/Foundation.h>

//! Project version number for UmoAuthSdk.
FOUNDATION_EXPORT double UmoAuthSdkVersionNumber;

//! Project version string for UmoAuthSdk.
FOUNDATION_EXPORT const unsigned char UmoAuthSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UmoAuthSdk/PublicHeader.h>


